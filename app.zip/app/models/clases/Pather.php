<?php 
    class Pather  
    {
        protected $user;
        protected $pass;
        protected $table;
    }
    
?>