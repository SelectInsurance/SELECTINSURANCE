<?php 
echo '<img src="' . $dir . basename($filename) . '" /><hr/>';
?>