<nav class="sticky-top">
    <div class="shadow-lg navbar navbar-expand-lg ColorSecundario navbar-dark ColorPrincipal" id="nav-tab" role="tablist">
        <div class="collapse navbar-collapse" id="navbarNavAltMarkup">
            <div class="nav navbar-nav">
                <a href="" class="nav-link active" id="nav-Inicio-tab" data-bs-toggle="tab" data-bs-target="#nav-Inicio" role="tab" aria-controls="nav-Inicio">INICIO</a>
                <a href="" class="nav-link" id="nav-Eventos-tab" data-bs-toggle="tab" data-bs-target="#nav-Eventos" role="tab" aria-controls="nav-Eventos">EVENTOS</a>
                <a href="" class="nav-link" id="nav-Cotizador-tab" data-bs-toggle="tab" data-bs-target="#nav-Cotizador" role="tab" aria-controls="nav-Cotizador">COTIZADOR</a>
                <a href="" class="nav-link" id="nav-Servicios-tab" data-bs-toggle="tab" data-bs-target="#nav-Servicios" role="tab" aria-controls="nav-Servicios">SERVICIOS</a>
                <a href="" class="nav-link" id="nav-Testimonios-tab" data-bs-toggle="tab" data-bs-target="#nav-Testimonios" role="tab" aria-controls="nav-Testimonios">TESTIMONIOS</a>
                <a href="" class="nav-link" id="nav-Contacto-tab" data-bs-toggle="tab" data-bs-target="#nav-Contacto" role="tab" aria-controls="nav-Contacto">CONTACTO</a>
                <a href="" class="nav-link" id="nav-Agentes-tab" data-bs-toggle="tab" data-bs-target="#nav-Agentes" role="tab" aria-controls="nav-Agentes">AGENTES</a>
            </div>
        </div>
        <a class="navbar-brand d-flex"><img src="app\views\assets\img\LogoWhite.webp" height="75"></a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNavAltMarkup" aria-controls="navbarNavAltMarkup" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
    </div>
</nav>





<!--<nav id="paginaSelectInsurance" class="shadow-lg navbar navbar-expand-lg navbar-light bg-light sticky-top">
    <div class="container-fluid ColorTextoOscuro">
        <div class="collapse navbar-collapse" id="navbarNavAltMarkup">
            <div class="navbar-nav">
            <a class="nav-link" href="./">INICIO</a>
                <a class="nav-link" href="./#Cotizador">COTIZADOR ONLINE</a>
                <a class="nav-link" href="./#Servicios">SERVICIOS</a>
                <a class="nav-link" href="./#Testimonios">TESTIMONIOS</a>
                <a class="nav-link" href="./#Contacto">CONTACTO</a>
                <a class="nav-link" href="agentes">AGENTES</a>
            </div>
        </div>
        <a class="navbar-brand d-flex"><img src="app/views/assets/img/Logo2.png" height="75"></a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNavAltMarkup" aria-controls="navbarNavAltMarkup" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
    </div>
</nav>-->