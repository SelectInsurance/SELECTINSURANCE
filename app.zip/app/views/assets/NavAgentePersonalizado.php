<nav id="paginaSelectInsurance" class="shadow-lg navbar navbar-expand-lg ColorSecundario navbar-dark ColorPrincipal sticky-top">
    <div class="container-fluid ColorTextoOscuro">
        <div class="collapse navbar-collapse" id="navbarNavAltMarkup">
            <div class="navbar-nav">
                <a class="nav-link" href="./">INICIO</a>
                <a class="nav-link" href="#Cotizador">COTIZADOR ONLINE</a>
                <a class="nav-link" href="#Servicios">SERVICIOS</a>
                <a class="nav-link" href="#Contacto">CONTACTO</a>
            </div>
        </div>
        <a class="navbar-brand d-flex" href="./"><img src="app\views\assets\img\LogoWhite.webp" height="75"></a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNavAltMarkup" aria-controls="navbarNavAltMarkup" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
    </div>
</nav>