<!--<div class="container-fluid">
    <div class="row">
        <div class="container-fluid ImagenAgentes img-fluid ImagenFija">
            <div class="row ColorSecundarioTranslucido">
                <div class="col-12 col-sm-6 col-md-3 col-lg-3 text-center"><br><br><br><br><br><br><br><br>
                    <a href="./VideosSalud" class="btn btn-outline-success btn-lg "><i class="fas fa-video fa-6x"></i></a><br><br>
                    <label class="text-white">Galeria de Videos de Salud</label><br><br><br><br><br><br><br><br><br><br><br><br><br>
                </div>
                <div class="col-12 col-sm-6 col-md-3 col-lg-3 text-center"><br><br><br><br><br><br><br><br>
                    <a href="" class="btn btn-outline-success btn-lg "><i class="fas fa-database fa-6x"></i></a><br><br>
                    <label class="text-white">CRM Select</label><br><br><br><br><br><br><br><br><br><br><br><br><br>
                </div>
                <div class="col-12 col-sm-6 col-md-3 col-lg-3 text-center"><br><br><br><br><br><br><br><br>
                    <a href="" class="btn btn-outline-success btn-lg "><i class="fas fa-headset fa-6x"></i></a><br><br>
                    <label class="text-white">Contact Center</label><br><br><br><br><br><br><br><br><br><br><br><br><br>
                </div>
                <div class="col-12 col-sm-6 col-md-3 col-lg-3 text-center"><br><br><br><br><br><br><br><br>
                    <a href="./VideosVida" class="btn btn-outline-success btn-lg "><i class="fas fa-film fa-6x"></i></a><br><br>
                    <label class="text-white">Galeria de Videos de Vida</label><br><br><br><br><br><br><br><br><br><br><br><br><br>
                </div>
            </div>
        </div>
    </div>
    <div class="row ColorPrincipal text-white">
        <div class="container"><br>
            <h4 class="text-white text-center">Contactenos</h4>
            <hr>
            <div class="row">
                <div class="col-12 col-sm-6 col-md-3 col-lg-3 text-center">
                    <img src="app/views/assets/img/LogoColorReal.png" alt="Select Insurance" height="80px" title="Select Insurance"><br><br>
                </div>
                <div class="col-12 col-md-1 col-lg-1"></div>
                <div class="col-12 col-sm-6 col-md-3 col-lg-3"><br><br>
                    <p><b>CONTÁCTENOS</b></p>
                </div>
                <div class="col-12 col-sm-6 col-md-2 col-lg-2"><br><br>
                    <p><b>ENLACES</b></p>
                </div>
                <div class="col-12 col-sm-6 col-md-3 col-lg-3"><br><br>
                    <p><b>ZONA DE AFILIADOS</b></p>
                </div>
            </div>
            <div class="row">
                <div class="col-12 col-sm-6 col-md-3 col-lg-3 text-center">
                    <p class="fs-7">
                        Select Insurance And Financial
                        Services nace en el año 2009 teniendo
                        en cuenta la necesidad de las personas
                        como una compañía dedicada a la venta y el
                        asesoramiento de seguros de vida y hoy es
                        una compañía especializada en aseguramiento, plan
                        de retiro y planes de inversión.
                    </p>
                </div>
                <div class="col-12 col-md-1 col-lg-1"></div>
                <div class="col-12 col-sm-6 col-md-3 col-lg-3">

                    <p class="lh-lg">
                        Tel.: (786) 216 1936 <br>

                        Email: contact@selectinsurance.info <br>

                        Skype: contact insurance <br>

                        Dirección: 7791 NW 46 ST. SUITE 112 DORAL, FL 33166 <br>
                    </p>
                </div>
                <div class="col-12 col-sm-6 col-md-2 col-lg-2">
                    <p class="lh-lg">
                        Cotizador Online <br>

                        Nuestros Servicios <br>

                        Testimonios <br>

                        Contacto <br>
                    </p>
                </div>
                <div class="col-12 col-sm-6 col-md-3 col-lg-3">
                    <p class="lh-lg">
                        FAQ <br>

                        Blog <br>

                        Crm <br>

                        Galería <br>
                    </p>
                </div>
            </div>
            <h6 class="text-end">Copyright © <?php echo date('M').' '.date('Y'); ?> Select Insurance.</h6>
        </div>
    </div>
</div>-->