<br><br><br><br>
<div class="container">
    <h1 class="text-center">Administracion</h1>
    <div class="row">
        <div class="col-12 col-sm-2 col-md-4 col-lg-4"></div>
        <div class="col-12 col-sm-8 col-md-4 col-lg-4 shadow p-3 mb-5">
            <form action="./ValidacionManagmentLogin" method="post">
                <p>
                    <label for="user">Usuario:</label>
                    <input class="form-control" type="text" name="user" id="user" required="required" placeholder="Ingrese Usuario">
                </p>
                <p>
                    <label for="pass">Contraseña:</label>
                    <input class="form-control" type="password" name="pass" id="pass" required="required" placeholder="Ingrese Contraseña">
                </p>
                <p class="text-center">
                    <input type="submit" value="Ingresar" class="btn btn-outline-success" name="btnmanagmentlogin">
                </p>
            </form>
        </div>
        <div class="col-12 col-sm-2 col-md-4 col-lg-4"></div>
    </div>
</div>